//
//  ViewController.swift
//  app-swoosh
//
//  Created by Mark Price on 6/12/17.
//  Copyright © 2017 Devslopes. All rights reserved.
//

import UIKit

class WelcomeVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func unwindFromSkillVC(unwindSegue: UIStoryboardSegue) {
        
    }


}

