//
//  Player.swift
//  app-swoosh
//
//  Created by Mark Price on 6/15/17.
//  Copyright © 2017 Devslopes. All rights reserved.
//

import Foundation

struct Player {
    var desiredLeague: String!
    var selectedSkillLevel: String!
}
