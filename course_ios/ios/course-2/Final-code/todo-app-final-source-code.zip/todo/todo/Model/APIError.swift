//
//  APIError.swift
//  todo
//
//  Created by hax0r-MBP on 8/16/19.
//  Copyright © 2019 Devslopes. All rights reserved.
//

import Foundation

struct APIError: Codable {
    let message: String
}
